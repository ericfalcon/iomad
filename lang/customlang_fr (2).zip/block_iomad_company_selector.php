<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://learnpre.norm-uni.fr
 *
 * @package    block
 * @subpackage iomad_company_selector
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['currentcompany'] = 'L\'entreprise actuelle est';
$string['currentcompanyname'] = 'Entreprise actuelle, <b>\'{$a}\'</b>';
$string['iomad_company_selector:addinstance'] = 'Ajouter un nouveau bloc IOMAD de sélection de société';
$string['iomad_company_selector:myaddinstance'] = 'Ajouter un nouveau bloc IOMAD de sélection de société au tableau de bord des utilisateurs';
$string['nocurrentcompany'] = 'Veuillez sélectionner une entreprise dans la liste déroulante';
$string['pluginname'] = 'iomad - Sélecteur d\'entreprise';
$string['privacy:metadata'] = 'Le bloc IOMAD de sélection de société  affiche uniquement les données stockées à d’autres emplacements.';
$string['selectacompany'] = 'Sélectionnez une entreprise';
$string['title'] = 'Sélection de l\'entreprise';
